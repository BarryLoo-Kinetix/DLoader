(1) GH-2.0

Source code of GH-2.0 Library are packaged in the <GH-2.0.jar> file together with
the corresponding class file.

(2) iText 5.5.7

Source code of iText 5.5.7 are packaged in the <itextpdf-5.5.7-sources.jar>.
Class files are packaged in the <itextpdf-5.5.7.jar>

(3) bcprov-jdk15on

Source code of bcprov-jdk15on are packaged in the <bcprov-jdk15on-1.57-sources.jar>.
Class files are packaged in the <bcprov-jdk15on-157.jar>
